--
-- backup-2025-01-22_09-58-54.sql.gz


DROP TABLE IF EXISTS `AVIS`;
CREATE TABLE `AVIS` (
  `numero` int(5) NOT NULL AUTO_INCREMENT,
  `datePost` datetime NOT NULL,
  `message` varchar(256) NOT NULL,
  `note` int(2) DEFAULT NULL,
  `numero_concerne` int(5) NOT NULL,
  `numero_commentateur` int(5) NOT NULL,
  PRIMARY KEY (`numero`),
  KEY `Fk_concerne` (`numero_concerne`),
  KEY `Fk_commentateur` (`numero_commentateur`),
  CONSTRAINT `Fk_commentateur` FOREIGN KEY (`numero_commentateur`) REFERENCES `ETUDIANT` (`numero`),
  CONSTRAINT `Fk_concerne` FOREIGN KEY (`numero_concerne`) REFERENCES `ETUDIANT` (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO `AVIS` VALUES ('1','2024-12-03 00:00:00','Bon trajet','4','2','3');
INSERT INTO `AVIS` VALUES ('2','2024-12-03 00:00:00','Mauvaise musique dans la voiture','1','5','1');
INSERT INTO `AVIS` VALUES ('3','1961-05-03 00:00:00','Bof','3','1','8');
INSERT INTO `AVIS` VALUES ('4','2024-12-04 00:00:00','Commentaire','4','12','10');
INSERT INTO `AVIS` VALUES ('5','2024-12-04 00:00:00','Commentaire','4','12','10');
INSERT INTO `AVIS` VALUES ('6','2024-12-04 00:00:00','Il se croit dans Taxi 5','1','1','10');
INSERT INTO `AVIS` VALUES ('7','2024-12-04 00:00:00','Ratio','1','2','5');
INSERT INTO `AVIS` VALUES ('8','2024-12-09 00:00:00','Nul','1','1','10');
INSERT INTO `AVIS` VALUES ('9','2024-12-09 00:00:00','Pas mal','5','1','10');
INSERT INTO `AVIS` VALUES ('10','2024-12-09 11:15:12','Avis','1','1','10');
INSERT INTO `AVIS` VALUES ('11','2024-12-09 00:00:00','z','2','1','10');
INSERT INTO `AVIS` VALUES ('12','2024-12-09 11:20:57','Vu le prix, la qualit� m�diocre ne m''�tonne pas','4','12','10');
INSERT INTO `AVIS` VALUES ('13','2024-12-09 01:08:14','Prestation m�diocre','1','2','5');
INSERT INTO `AVIS` VALUES ('14','2024-12-11 10:48:56','Trajet d�sastreux malgr� mon arriv�e � destination','3','3','2');
INSERT INTO `AVIS` VALUES ('15','2024-12-14 12:22:18','Le conducteur �tait aussi agr�able qu''une porte de prison','1','2','5');
INSERT INTO `AVIS` VALUES ('16','2024-12-16 09:47:44','Bon trajet','5','1','5');
INSERT INTO `AVIS` VALUES ('17','2024-12-17 09:45:41','','1','2','5');
INSERT INTO `AVIS` VALUES ('18','2024-12-17 09:47:33','Ok','3','2','5');
INSERT INTO `AVIS` VALUES ('19','2024-12-17 09:47:42','','1','2','5');
INSERT INTO `AVIS` VALUES ('20','2024-12-17 10:00:22','','4','1','5');
INSERT INTO `AVIS` VALUES ('21','2024-12-17 10:42:11','','1','2','5');
INSERT INTO `AVIS` VALUES ('22','2024-12-17 10:50:30','','3','2','5');
INSERT INTO `AVIS` VALUES ('23','2024-12-19 08:24:45','On a failli se prendre un mur','2','2','2');
INSERT INTO `AVIS` VALUES ('24','2024-12-19 11:54:44','pas ouf, j''ai cru finir dans un mur','2','2','4');
INSERT INTO `AVIS` VALUES ('25','2025-01-08 06:48:55','Trajet nul j''ai faillit mourir','3','2','32');
INSERT INTO `AVIS` VALUES ('26','2025-01-11 04:41:59','Test','5','2','1');
INSERT INTO `AVIS` VALUES ('27','2025-01-13 14:46:00','Excellent pilote','5','2','3');
INSERT INTO `AVIS` VALUES ('28','2025-01-21 02:38:57','Très bon conducteur (en 2 mots)','1','3','2');


DROP TABLE IF EXISTS `BADGE`;
CREATE TABLE `BADGE` (
  `numero` int(5) NOT NULL AUTO_INCREMENT,
  `titre` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `BADGE` VALUES ('1','Conducteur �toil�','etoile.png');
INSERT INTO `BADGE` VALUES ('2','Passager r�curent','recurent.png');


DROP TABLE IF EXISTS `CHOISIR`;
CREATE TABLE `CHOISIR` (
  `numero_trajet` int(5) NOT NULL,
  `numero_passager` int(5) NOT NULL,
  KEY `Fk_trajet` (`numero_trajet`),
  KEY `Fk_passager` (`numero_passager`),
  CONSTRAINT `Fk_passager` FOREIGN KEY (`numero_passager`) REFERENCES `ETUDIANT` (`numero`),
  CONSTRAINT `Fk_trajet` FOREIGN KEY (`numero_trajet`) REFERENCES `TRAJET` (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `CHOISIR` VALUES ('1','3');
INSERT INTO `CHOISIR` VALUES ('2','2');
INSERT INTO `CHOISIR` VALUES ('2','3');
INSERT INTO `CHOISIR` VALUES ('6','5');
INSERT INTO `CHOISIR` VALUES ('6','3');
INSERT INTO `CHOISIR` VALUES ('11','10');
INSERT INTO `CHOISIR` VALUES ('9','10');
INSERT INTO `CHOISIR` VALUES ('10','10');
INSERT INTO `CHOISIR` VALUES ('17','34');
INSERT INTO `CHOISIR` VALUES ('17','14');
INSERT INTO `CHOISIR` VALUES ('2','14');


DROP TABLE IF EXISTS `ETUDIANT`;
CREATE TABLE `ETUDIANT` (
  `numero` int(5) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `dateNaiss` date DEFAULT NULL,
  `adresseMail` varchar(50) DEFAULT NULL,
  `numTelephone` varchar(10) DEFAULT NULL,
  `numero_voiture` int(5) DEFAULT NULL,
  `photoProfil` varchar(99) DEFAULT 'photoProfilParDefaut.png',
  `motDePasse` varchar(999) NOT NULL,
  `token_reinitialisation` varchar(250) DEFAULT NULL,
  `expiration_token` datetime DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`numero`),
  KEY `Fk_voiture` (`numero_voiture`),
  CONSTRAINT `Fk_voiture` FOREIGN KEY (`numero_voiture`) REFERENCES `VOITURE` (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

INSERT INTO `ETUDIANT` VALUES ('1','Birembaux','Theo','2004-08-24','tbirembaux@iutbayonne.univ-pau.fr','0783324454','2','photoProfilParDefaut.png','$2y$10$O9DRR47O5SAOQD9uFajQTukOSrhJiQB204AkDhs9W59pjYEXCivhK',NULL,NULL,'83f5f4e204565ec0833a1b70586ed1b3');
INSERT INTO `ETUDIANT` VALUES ('2','Rosalie','Thibault','2003-05-30','trosalie@gmail.com','0692354381','3','photoProfilParDefaut.png','$2y$10$TAsXJ/4xECVsMu.gRBTIRerTeCqZYQe/phroLUm7eWxmtBvp5TTBG',NULL,NULL,'e0b00d572a31761655727003927d4ade');
INSERT INTO `ETUDIANT` VALUES ('3','Galles','Titouan','2003-05-30','tgalles@iutbayonne.univ-pau.fr','0692354381','6','20241219_090214.jpg','$2y$10$ls8/mUv9m/FiraHV6QcIrOA9zBeGdYJEz9phXQiWaW6uCtlFgxowK',NULL,NULL,'f68ce3cf7a48d05c24b12a97823d9bae');
INSERT INTO `ETUDIANT` VALUES ('4','Dutournier','Candice','2006-01-21','cdutourni001@iutbayonne.univ-pau.fr','0754864534','2','cactus.jpg','$2y$10$FY2owQ04rVcil4m/gvYejuHCe.RFOpoV4Egz4kuT0Zkmcwk87QPeq','ecababa2fd83ab126eecde94a5040ec0134cce436f26b9577246df1b6be82e9b','2025-01-21 15:02:41','dfafafe1b38feb1a8647cca3d86f6c0a');
INSERT INTO `ETUDIANT` VALUES ('5','Oulai','Kevin','2003-05-30','koulai001@iutbayonne.univ-pau.fr','0692354381','9','photoProfilParDefaut.png','$2y$10$LngkUSxhsvzm2GY0oH95mOs90svMcw.gfD3kHiantdfrSLeCJMhgm',NULL,NULL,'0da304e628a7defaf380486207405dbf');
INSERT INTO `ETUDIANT` VALUES ('6','Marquesuzaa','Christophe','1955-05-30','marquesu@univ-pau.fr','0792657844','1','photoProfilParDefaut.png','$2y$10$gxXh.rGXh.o9XtfL.sYEs.TpM0hxK6UIofTRjpBjtKmQydn59RIvu',NULL,NULL,'e7b41e0770b702249814361d2095f938');
INSERT INTO `ETUDIANT` VALUES ('7','test2','t','2024-11-29','test2@univ-pau.fr','0000000000',NULL,'photoProfilParDefaut.png','$2y$10$qOVelHoAaZ3J9YVmb4SeK.wmbyzrgxot6EWLy4uCirVILHUgqlGBK',NULL,NULL,'b0fbdc77eb7f1e8ae03da2ac4dfa5887');
INSERT INTO `ETUDIANT` VALUES ('8','t','t','2024-11-22','t@gmail.com','0000000000','1','photoProfilParDefaut.png','$2y$10$43GO.xeX.IIhhJgay/AGLejYDv9wAXNCdKEF4DVNWWg67XOeN7KnW',NULL,NULL,'f0bd44386ad059edf853ce2d55f2cd60');
INSERT INTO `ETUDIANT` VALUES ('9','Testun','Test','2025-01-10','test1@gmail.com','0506070809',NULL,'1645855549.png','$2y$10$LjJqANOWy34NRugENMDh2ujmfeVyJo2QGhvtgg8pepc6oqFlCHcRq',NULL,NULL,'1fc9dac4d8ab261921f19418a946e4d3');
INSERT INTO `ETUDIANT` VALUES ('10','TestImage','image','2024-11-01','testImage@gmail.com','0102030405','1',NULL,'$2y$10$CBBukzOGam8yjuyt.UTQPuo/fGbAAjo48/G5qNhNIdlq1mbRc48Vi',NULL,NULL,'47b22234f9af085a129e87fc7d99b1cf');
INSERT INTO `ETUDIANT` VALUES ('11','Jacques','Jean','2003-05-30','trosalie@univ-pau.fr','0632123456','1','photoProfilParDefaut.png','$2y$10$0I6bj9kCzG8FAMeGsOfkH.lXoLvn2KBqbj7FlN2PnfrWO3WswsmbW',NULL,NULL,'f949f6db061052a556582d3364879a4b');
INSERT INTO `ETUDIANT` VALUES ('12','Dupont','Jean','2024-12-01','exemple@gmail.com','0558634578',NULL,'574668014.png','$2y$10$4gGjd.O0rWYPIfJikXZ.R.7rhpFbF6aB1BrzkPi.t4LPxpB.XRZwO',NULL,NULL,'94212ea47d315c2b3cf1830e88dd0093');
INSERT INTO `ETUDIANT` VALUES ('13','tt','tt','2024-12-06','tt@gmail.com','0000000000','1','photoProfilParDefaut.png','$2y$10$Iyp/cT2U7zB8/ZqEJDsKIOiQnJbUYWZAqqHiasUszNvn0NJ4kHmD6',NULL,NULL,'ce2e8de453965f5e601256787e07930d');
INSERT INTO `ETUDIANT` VALUES ('14','Galles','Titouan','2005-11-20','titouangalles@gmail.com','0782807665','1','Thibault.jpg','$2y$10$XL0CIKe8PrsACEyfa3FhTOvAY1tARvCjfa0UtwkCTc3jXsZJuh7be',NULL,NULL,'e41602a6c89e0722f9ec80a0707da3bf');
INSERT INTO `ETUDIANT` VALUES ('15','Titouan','Galles','2005-11-20','titouanglles@gmail.com','0782807665','1','1645855549.png','$2y$10$loMQwcHTuLj8XTHYqGJeWOQQCVpnjBarnsHP456uAkP8RfqQqTYga',NULL,NULL,'d4c90d800da59191822c5b55e8d06c7d');
INSERT INTO `ETUDIANT` VALUES ('16','aaa','aaa','2024-12-01','aaaaatitouangalles@gmail.com','0782807665','1','photoProfilParDefaut.png','$2y$10$WbDxYrlyfSIs3dE3OWiGx.l1o3OqK6HQGCCIT1bNG9YISLn3/69Yu',NULL,NULL,'c477e2643ff11fd46ed9a30895fa3c9e');
INSERT INTO `ETUDIANT` VALUES ('17','aaaa','aaa','2024-12-07','aaaa@gmail.com','4545616666','1','photoProfilParDefaut.png','$2y$10$pSDHLq62atib36eBU48NyucDetEklsbf9sZbu48yMNDauDeBqz99C',NULL,NULL,'eb84f1fea9e94667c8947e7f1baaecc2');
INSERT INTO `ETUDIANT` VALUES ('18','aaaaa','azazazazaz','2024-12-18','azeazea@gmail.com','5644575465',NULL,'53562697.png','$2y$10$7y/8aSpelmNFzMaVcGiWLeU/5elHRrXZedTt3OL3xz2C6AxZ8toNS',NULL,NULL,'52305682af97be967ab4ed8706e02012');
INSERT INTO `ETUDIANT` VALUES ('19','Kevin','DEOULAI','2024-12-27','kevindeolai@gmail.com','8546878654',NULL,'1953347584.png','$2y$10$Q8vvtIP.Q0PpX3VifuXXMueJBAHsfSJ3a9jXLAybBjJ1j2HilWN3C',NULL,NULL,'d36832d71926af1122ff96e8a1db0536');
INSERT INTO `ETUDIANT` VALUES ('20','Dfkhg','Bgdthb','2024-12-18','ui@ui.fr','0486746467',NULL,'1568610435.png','$2y$10$m0azh/4kJbkDPwV.yB.ssuEve50DM.tuR77N35m9.OXe9oQRe4S9e',NULL,NULL,'87ce76403ed095d5fd29d8b0c4c69702');
INSERT INTO `ETUDIANT` VALUES ('21','aze','aze','2024-11-30','aez@za.com','7582785875',NULL,'31639427.png','$2y$10$eI/ANEyhzIbK.QQpUNjxp.SEeGMu8JKqg4SXUCph73XYtxrdeFsFe',NULL,NULL,'0');
INSERT INTO `ETUDIANT` VALUES ('22','testSalt','testSalt','2024-12-05','testSalt@gmail.com','1111111111',NULL,'104719887.png','$2y$10$JwOclacbkwGi1EUQ4in43eRIT87HHNIZ9XK7dWOXF9EBRaXY2U0Um',NULL,NULL,'898137cbeecabee669866c6eb14a6b7d');
INSERT INTO `ETUDIANT` VALUES ('23','dfkhg','bgdthb','2024-12-18','thy@thy.fr','0486746467',NULL,'197627674.png','$2y$10$9pX9gF0ARQUEw53BGuwG1uUCsOmdflx3CMDD.je5L4joehgWmgRMS',NULL,NULL,'f34b030c7c9905947901fc9073d737e2');
INSERT INTO `ETUDIANT` VALUES ('24','azioeuazeioauieo','azioeuazeioauieo','2025-01-11','azioeuazeioauieo@gmail.com','1231232131',NULL,'photoProfilParDefaut.png','$2y$10$Lo39.9V3K7QkVJDqP0rQDOw4BwIRUrzElkoKBahMYJ9Lu/OA/.9SW',NULL,NULL,'f9c815b7dfdc8b7115fea6a118927719');
INSERT INTO `ETUDIANT` VALUES ('25','Dupont','Jean','1998-05-30','covoit@gmail.com','1252525042',NULL,'photoProfilParDefaut.png','$2y$10$q1fYOfLLnZ2Mnk16FDfOcOwOALV2KDLda.VuXzqLepneNo.W31SRS',NULL,NULL,NULL);
INSERT INTO `ETUDIANT` VALUES ('26','Dupont de Ligones','Xavier','2025-01-18','xavier@terrasse.fr','0202022165',NULL,'1974777647.png','$2y$10$H3.i3j90xr9bt3NhCHRoju0ov3wRgftc9hK6sKDQv18yt4J1hmenu',NULL,NULL,'99198b3871b421e9639502c1d44d1cb3');
INSERT INTO `ETUDIANT` VALUES ('27','Dupont','Jean','2003-06-14','covoitetud@mail.com','0605050445',NULL,'photoProfilParDefaut.png','$2y$10$uBzJ5j0l2ea60psQSSYXeePwC2.CT9LHl5ICPT1tYmHwvOc0ZPv76',NULL,NULL,NULL);
INSERT INTO `ETUDIANT` VALUES ('28','azeaze','azeaze','1985-01-01','azeaze@gmail.com','0000000000',NULL,'photoProfilParDefaut.png','$2y$10$Dukfq.eA74rb2Kwi8J1oNOTX5.57D3gjhgqaw1f6jymWlQKBPbmoK',NULL,NULL,'8fc7ff4f73bb919fcd681697ded3b1d3');
INSERT INTO `ETUDIANT` VALUES ('29','testSal','testSal','1999-01-01','testSal@t.fr','0000000000',NULL,'photoProfilParDefaut.png','$2y$10$8cjyVz4OdKnsmJTNQq3Liu135IoDM1QqdzNl8DePKlkN/AV.OlUvy',NULL,NULL,'33fff05da187e3ca84c07e64e312987b');
INSERT INTO `ETUDIANT` VALUES ('30','testSal2','testSal2','1999-01-01','testSal2@c.fr','0000000000',NULL,'photoProfilParDefaut.png','$2y$10$a4WFvwCIOG8hFwRdIcutG.P2QukY9eUM175iKSGenNrDDPki3qtDi',NULL,NULL,'a85eb58a10258f315c449d21244b0f05');
INSERT INTO `ETUDIANT` VALUES ('31','testSal3','testSal3','1999-01-01','testSal3@c.fr','0000000000',NULL,'photoProfilParDefaut.png','$2y$10$TIfw7YIIDpwpLhWAf7sVcutEE/6CIGPcRGyi4x03Tw/KmpIUlhLJa',NULL,NULL,'d72c95f753083055e6e0415fbeea3af5');
INSERT INTO `ETUDIANT` VALUES ('32','Dupont','Jean','2005-06-08','thibault@miaijoda.com','1231213546',NULL,'photoProfilParDefaut.png','$2y$10$bFjECFlj.N9bIbm0wTMqVebpVWYYYy8YnLonly0eZLh0Z1zloONiC',NULL,NULL,NULL);
INSERT INTO `ETUDIANT` VALUES ('33','TestM','TestM','2000-01-01','testM@g.com','0000000000','11','photoProfilParDefaut.png','$2y$10$kXfvcBbAv63Lj450U3w9H.HY.i6.zk41ocuhsLc18L.sLo8p1.WKu',NULL,NULL,'fdb61bc45e5c5cd498e0ec1cc07c3759');
INSERT INTO `ETUDIANT` VALUES ('34','Rosalie','Thibault','2005-05-04','passager@gmail.com','1111111111','10','photoProfilParDefaut.png','$2y$10$e5OypsAZFh25iq689UhAyOPHqBAN3q3OohJn3QKpnF.MS53emzZ.u',NULL,NULL,'fe1f7dbf4be3597117c21c37503be7a9');
INSERT INTO `ETUDIANT` VALUES ('35','Test','InsertEtud','2003-02-01','insertetud@gmail.com','1234567894',NULL,'photoProfilParDefaut.png','$2y$10$5i8IXtro0YnHaSG5Y2JAFu67k1sFu6GkDnc9u9KCvWKt.jcVyrcJu',NULL,NULL,'f71f586cb5f4c1ec96f7789c52d40d99');
INSERT INTO `ETUDIANT` VALUES ('36','Test0','Test0','2004-11-12','test0@mail.com','0000000000',NULL,'photoProfilParDefaut.png','$2y$10$LBqf5uLB6PfgOw0Xg/yBXuV8chlEltHQoUrCRwavedWccq75YK7.K',NULL,NULL,'c19d3b9f5ef408b1fb66949843177fa1');


DROP TABLE IF EXISTS `LIEU`;
CREATE TABLE `LIEU` (
  `numero` int(5) NOT NULL AUTO_INCREMENT,
  `numRue` int(5) NOT NULL,
  `nomRue` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

INSERT INTO `LIEU` VALUES ('1','2','Allee parc Montaury','Anglet');
INSERT INTO `LIEU` VALUES ('2','14','Rue de la paix','Paris');
INSERT INTO `LIEU` VALUES ('3','5','Allee des Champs Elysees','Paris');
INSERT INTO `LIEU` VALUES ('4','4','Allee parc Montaury','Anglet');
INSERT INTO `LIEU` VALUES ('5','55','rue du Faubourg-Saint-Honor�','Paris');
INSERT INTO `LIEU` VALUES ('6','55','Rue de Mirambeau','Anglet');
INSERT INTO `LIEU` VALUES ('7','90','Avenue Henri de Navarre','Bayonne');
INSERT INTO `LIEU` VALUES ('8','16','avenue G�n�ral Leclerc','Dax');
INSERT INTO `LIEU` VALUES ('9','1','Place Verdun','Pau');
INSERT INTO `LIEU` VALUES ('10','54','rue de la Carrère','Mont');
INSERT INTO `LIEU` VALUES ('11','2','All�e parc Montaury','Anglet');
INSERT INTO `LIEU` VALUES ('12','64','Avenue marchande','Puyoo');
INSERT INTO `LIEU` VALUES ('13','1','Rue Tour Eiffel','Paris');
INSERT INTO `LIEU` VALUES ('14','4','Avenue Verdun','Anglet');
INSERT INTO `LIEU` VALUES ('15','1','Rue du college','Orthez');
INSERT INTO `LIEU` VALUES ('16','2','Aller parke mauntori','Englette');
INSERT INTO `LIEU` VALUES ('17','6','Avnu jorge','Iphone');
INSERT INTO `LIEU` VALUES ('18','4','Rueoubr zefji','ZRaze');
INSERT INTO `LIEU` VALUES ('19','54','impasse armantiou, saint paul le','dax');
INSERT INTO `LIEU` VALUES ('20','4','Reoubr zefji','ZRaze');
INSERT INTO `LIEU` VALUES ('21','4','Ru�eoubr zefji','ZRaze');
INSERT INTO `LIEU` VALUES ('22','6','Avnu jorge','Samsung');
INSERT INTO `LIEU` VALUES ('23','54','impasse armantiou, saint vincent d','paul');
INSERT INTO `LIEU` VALUES ('24','30','Disneyland','Paris');
INSERT INTO `LIEU` VALUES ('25','14','Rue de Paris','Paris');
INSERT INTO `LIEU` VALUES ('26','2','All�e du parc Montaury','Anglet');
INSERT INTO `LIEU` VALUES ('27','2','Allee du parc Montaury','Anglet');
INSERT INTO `LIEU` VALUES ('28','26','avenue mar�chal foch, Pyla su','mer');
INSERT INTO `LIEU` VALUES ('29','42','Allee parc montaury','Anglet');
INSERT INTO `LIEU` VALUES ('30','42','Allee du parc Montaury','Bordeaux');
INSERT INTO `LIEU` VALUES ('31','4','Allee parc Montaury','Lyon');


DROP TABLE IF EXISTS `OBTENIR`;
CREATE TABLE `OBTENIR` (
  `numero_etudiant` int(5) NOT NULL,
  `numero_badge` int(5) NOT NULL,
  KEY `Fk_etudiant` (`numero_etudiant`),
  KEY `Fk_badge` (`numero_badge`),
  CONSTRAINT `Fk_badge` FOREIGN KEY (`numero_badge`) REFERENCES `BADGE` (`numero`),
  CONSTRAINT `Fk_etudiant` FOREIGN KEY (`numero_etudiant`) REFERENCES `ETUDIANT` (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `OBTENIR` VALUES ('2','1');
INSERT INTO `OBTENIR` VALUES ('4','2');
INSERT INTO `OBTENIR` VALUES ('2','2');


DROP TABLE IF EXISTS `TRAJET`;
CREATE TABLE `TRAJET` (
  `numero` int(5) NOT NULL AUTO_INCREMENT,
  `heureDep` varchar(5) DEFAULT NULL,
  `heureArr` varchar(5) DEFAULT NULL,
  `prix` int(3) DEFAULT NULL,
  `dateDep` date DEFAULT NULL,
  `nbPlace` int(2) DEFAULT NULL,
  `numero_conducteur` int(5) DEFAULT NULL,
  `numero_lieu_depart` int(5) NOT NULL,
  `numero_lieu_arrivee` int(5) NOT NULL,
  PRIMARY KEY (`numero`),
  KEY `Fk_conducteur` (`numero_conducteur`),
  KEY `Fk_lieu_depart` (`numero_lieu_depart`),
  KEY `Fk_lieu_arrivee` (`numero_lieu_arrivee`),
  CONSTRAINT `Fk_conducteur` FOREIGN KEY (`numero_conducteur`) REFERENCES `ETUDIANT` (`numero`),
  CONSTRAINT `Fk_lieu_arrivee` FOREIGN KEY (`numero_lieu_arrivee`) REFERENCES `LIEU` (`numero`),
  CONSTRAINT `Fk_lieu_depart` FOREIGN KEY (`numero_lieu_depart`) REFERENCES `LIEU` (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `TRAJET` VALUES ('1','17:30','18:00','15','2024-11-06','3','1','2','3');
INSERT INTO `TRAJET` VALUES ('2','10:30','13:00','50','2025-01-30','2','3','2','1');
INSERT INTO `TRAJET` VALUES ('3','10:30','14:00','20','2024-11-06','2','3','2','1');
INSERT INTO `TRAJET` VALUES ('4','11:30','14:00','20','2024-11-06','2','1','2','1');
INSERT INTO `TRAJET` VALUES ('5','10:00','15:00','100','2024-11-06','4','1','1','3');
INSERT INTO `TRAJET` VALUES ('6','20:07','20:09','1','2024-11-06','1','1','1','6');
INSERT INTO `TRAJET` VALUES ('7','12:50','13:25','25','2024-11-06','3','1','1','7');
INSERT INTO `TRAJET` VALUES ('8','20:15','21:00','15','2024-11-06','4','1','8','9');
INSERT INTO `TRAJET` VALUES ('9','13:07','13:07','1','2024-11-06','2','1','11','12');
INSERT INTO `TRAJET` VALUES ('10','13:09','13:15','1','2024-11-06','2','12','11','12');
INSERT INTO `TRAJET` VALUES ('11','02:10','07:00','60','2024-11-07','4','1','1','4');
INSERT INTO `TRAJET` VALUES ('12','12:22','13:22','12','2024-11-06','3','1','15','1');
INSERT INTO `TRAJET` VALUES ('14','12:56','13:56','1','2024-12-25','1','5','18','18');
INSERT INTO `TRAJET` VALUES ('15','15:59','17:59','1','2024-12-28','1','5','20','21');
INSERT INTO `TRAJET` VALUES ('17','06:00','08:00','5','2025-01-20','4','2','25','26');
INSERT INTO `TRAJET` VALUES ('18','10:00','15:00','13','2025-01-22','4','2','1','4');
INSERT INTO `TRAJET` VALUES ('19','10:00','15:00','13','2025-01-22','4','2','1','4');
INSERT INTO `TRAJET` VALUES ('20','05:00','06:00','50','2025-01-30','2','2','1','1');
INSERT INTO `TRAJET` VALUES ('21','18:30','18:35','5','2025-01-22','4','2','30','31');


DROP TABLE IF EXISTS `VOITURE`;
CREATE TABLE `VOITURE` (
  `numero` int(5) NOT NULL AUTO_INCREMENT,
  `modele` varchar(50) DEFAULT NULL,
  `marque` varchar(50) DEFAULT NULL,
  `nbPlace` int(2) DEFAULT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `VOITURE` VALUES ('1','911','Porsche','3');
INSERT INTO `VOITURE` VALUES ('2','Clio','Renault','4');
INSERT INTO `VOITURE` VALUES ('3','GT-R','Nissan','4');
INSERT INTO `VOITURE` VALUES ('4','Clio RS3','Renault','30');
INSERT INTO `VOITURE` VALUES ('5',NULL,NULL,NULL);
INSERT INTO `VOITURE` VALUES ('6','Multiplat','Fiat','0');
INSERT INTO `VOITURE` VALUES ('7',NULL,NULL,NULL);
INSERT INTO `VOITURE` VALUES ('8','Grand Artic','BUS','300');
INSERT INTO `VOITURE` VALUES ('9','Gran Artic 300','Volvo','300');
INSERT INTO `VOITURE` VALUES ('10','Niro EV','KIA','5');
INSERT INTO `VOITURE` VALUES ('11','EV Niro','Kia','5');
